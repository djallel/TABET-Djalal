export interface EveningEvent {
    id: number;
    title: string;
    date: string;
    description: string;
}